Projeto Dr Jacques

Este projeto foi desenvolvido em PHP, HTML, Bootstrap, jQuery e MySQL.

Utiliza��o do template bootstrap Bethany
- Theme Name: Bethany
- Theme URL: https://bootstrapmade.com/bethany-free-onepage-bootstrap-theme/
- Theme Author: BootstrapMade.com

Informa��es Dr Jacques
Nome: Dr Jacques - Advogado Virtual
Autor: C�ssio Deon
